package com.example.smsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
